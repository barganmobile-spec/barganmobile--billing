BARGAN MOBILES OFFLINE BILLING - ஆரம்ப Prototype

இது Android மொபைலை மைய Database ஆகக் கொண்டு, Mobile Hotspot வழியாக Windows 11 கணினியில் browser மூலம் பயன்படுத்தும் ஆரம்ப project.

அமைப்பு:
1) Android Studio (Windows/Mac/Linux) நிறுவவும்.
2) இந்த ZIP-ஐ Extract செய்து Android Studio-வில் BarganMobilesOffline கோப்புறையை Open செய்யவும்.
3) Gradle sync முடிந்ததும் Android phone-ஐ USB மூலம் இணைத்து Run செய்யவும்.
4) மொபைலில் BARGAN MOBILES Billing app திறந்து Mobile Hotspot ON செய்யவும்.
5) App காட்டும் http://PHONE-IP:8080 முகவரியை Windows 11 கணினியின் Chrome/Edge-ல் திறக்கவும்.
6) Phone app இயங்கிக்கொண்டிருக்க வேண்டும்; அதுவே SQLite Database server.

முக்கிய வரம்புகள்:
- இது ஆரம்ப Prototype; முழுமையான GST-compliant accounting package அல்ல.
- தற்போது ஒரு bill-க்கு ஒரு product/service line மட்டுமே உள்ளது.
- GST rate-ஐ பயனர் தேர்வு செய்கிறார்; HSN/SAC, GST invoice legal validation, e-invoice/e-way bill, returns, barcode, purchase ledger ஆகியவை சேர்க்கப்படவில்லை.
- Android-ல் Hotspot client isolation / Android vendor restrictions இருந்தால் PC இணைப்பு அல்லது IP discovery வேலை செய்யாமல் இருக்கலாம். App foreground-ல் வைத்திருக்கவும்.
- Bill/stock data Android phone-இல் மட்டுமே சேமிக்கப்படுகிறது. Phone backup/export, authentication, encrypted backup, delete/edit audit trail ஆகியவை production release-க்கு முன் சேர்க்கப்பட வேண்டும்.
- Android Studio மூலம் APK build செய்ய வேண்டும். இந்த ZIP நேரடியாக நிறுவக்கூடிய APK அல்ல.
- முதல் முறையாக compile செய்ய Gradle dependency download-க்கு internet தேவைப்படலாம்; பயன்பாட்டின் போது internet தேவையில்லை.
