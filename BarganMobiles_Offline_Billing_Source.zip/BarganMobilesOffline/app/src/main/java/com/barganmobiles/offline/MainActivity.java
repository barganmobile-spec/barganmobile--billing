package com.barganmobiles.offline;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.view.*;
import android.graphics.Typeface;
import java.net.*;
import fi.iki.elonen.NanoHTTPD;

public class MainActivity extends Activity {
  Server server;
  TextView status;
  public void onCreate(Bundle b) {
    super.onCreate(b);
    LinearLayout l = new LinearLayout(this); l.setPadding(24,36,24,24); l.setOrientation(1);
    TextView title = new TextView(this); title.setText("BARGAN MOBILES"); title.setTextSize(26); title.setTypeface(null, Typeface.BOLD);
    l.addView(title);
    TextView sub = new TextView(this); sub.setText("OFFLINE SALES & SERVICE BILLING"); sub.setTextSize(14); l.addView(sub);
    status = new TextView(this); status.setText("\nStarting local billing server..."); status.setTextSize(17); l.addView(status);
    Button start = new Button(this); start.setText("START / RESTART SERVER"); start.setOnClickListener(v -> startServer()); l.addView(start);
    TextView help = new TextView(this); help.setText("\nHOW TO CONNECT\n1. Turn ON this phone's Mobile Hotspot.\n2. Connect your Windows 11 PC to that hotspot.\n3. Open the address shown above in Chrome or Edge.\n4. Keep this app open while using billing on the PC.\n\nNo internet connection is required. Both devices use the phone's local database."); l.addView(help);
    setContentView(l); startServer();
  }
  void startServer() {
    try {
      if(server!=null) server.stop();
      server = new Server(); server.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false);
      String ip = getIp();
      status.setText("\nSERVER RUNNING\nOpen on this phone or PC:\nhttp://"+ip+":8080\n\nKeep this screen/app running.");
    } catch(Exception e) { status.setText("Could not start server: "+e.getMessage()); }
  }
  String getIp() {
    try {
      for(java.util.Enumeration<NetworkInterface> en=NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();) {
        NetworkInterface ni=en.nextElement();
        for(java.util.Enumeration<InetAddress> a=ni.getInetAddresses(); a.hasMoreElements();) {
          InetAddress x=a.nextElement(); String s=x.getHostAddress();
          if(!x.isLoopbackAddress() && s.indexOf(':')<0 && (s.startsWith("192.168.") || s.startsWith("172.") || s.startsWith("10."))) return s;
        }
      }
    } catch(Exception ignored) {}
    return "PHONE-IP";
  }
  @Override public void onDestroy(){ if(server!=null) server.stop(); super.onDestroy(); }
  class Server extends NanoHTTPD {
    DB db;
    Server() throws java.io.IOException { super(8080); db=new DB(MainActivity.this); }
    @Override public Response serve(IHTTPSession s) {
      String uri=s.getUri();
      if(uri.equals("/api/data")) return newFixedLengthResponse(Response.Status.OK,"application/json",db.read());
      if(uri.equals("/api/save") && s.getMethod()==Method.POST) {
        try { java.util.Map<String,String> p=new java.util.HashMap<>(); s.parseBody(p); db.write(p.get("postData")); return newFixedLengthResponse("{\"ok\":true}"); }
        catch(Exception e){ return newFixedLengthResponse(Response.Status.INTERNAL_ERROR,"application/json","{\"error\":\"save failed\"}"); }
      }
      try {
        java.io.InputStream in=getAssets().open("index.html");
        java.util.Scanner sc=new java.util.Scanner(in,"UTF-8").useDelimiter("\\A");
        return newFixedLengthResponse(Response.Status.OK,"text/html; charset=utf-8",sc.hasNext()?sc.next():"");
      } catch(Exception e){ return newFixedLengthResponse("App page missing"); }
    }
  }
}
