package com.barganmobiles.offline;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import org.json.*;
class DB extends SQLiteOpenHelper {
 DB(Context c){ super(c,"barganmobiles.db",null,1); }
 public void onCreate(SQLiteDatabase d){ d.execSQL("CREATE TABLE state(id INTEGER PRIMARY KEY CHECK(id=1), data TEXT)"); d.execSQL("INSERT INTO state VALUES(1, '{\"bills\":[],\"products\":[],\"customers\":[]}')"); }
 public void onUpgrade(SQLiteDatabase d,int o,int n){}
 synchronized String read(){ Cursor c=getReadableDatabase().rawQuery("SELECT data FROM state WHERE id=1",null); String s="{}"; if(c.moveToFirst())s=c.getString(0); c.close(); return s; }
 synchronized void write(String s){ if(s==null)return; try { new JSONObject(s); ContentValues v=new ContentValues(); v.put("data",s); getWritableDatabase().update("state",v,"id=1",null); } catch(Exception ignored){} }
}
